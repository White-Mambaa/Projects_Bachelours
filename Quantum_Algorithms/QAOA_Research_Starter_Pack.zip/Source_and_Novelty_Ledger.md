# Octad Source and Novelty Ledger

## Eight canonical references (chapter/page verification pending)
1. Nielsen & Chuang — *Quantum Computation and Quantum Information*
2. Lipton & Regan — *Quantum Algorithms via Linear Algebra*
3. Buchmann — *Introduction to Quantum Algorithms*
4. Rieffel & Polak — *Quantum Computing: A Gentle Introduction*
5. Mermin — *Quantum Computer Science: An Introduction*
6. Aaronson — *Quantum Computing Since Democritus*
7. Kaye, Laflamme & Mosca — *An Introduction to Quantum Computing*
8. Nakahara & Ohmi — *Quantum Computing: From Linear Algebra to Physical Realizations*

## External prior work for attribution and gap analysis (not substitutes for the Octad)
- Farhi, Goldstone & Gutmann (2014), *A Quantum Approximate Optimization Algorithm*, https://arxiv.org/abs/1411.4028
- Qiskit Algorithms QAOA tutorial, https://qiskit-community.github.io/qiskit-algorithms/tutorials/05_qaoa.html
- OpenQAOA repository, https://github.com/entropicalabs/openqaoa

## Claim tracking template
| Claim | Type | Supporting source | Verified location | Status |
|---|---|---|---|---|
| Quantum evolution is unitary for Hermitian generators | Foundational | Octad | Pending edition lookup | Pending |
| QAOA originally proposed in 2014 | Historical | Farhi et al. | arXiv 1411.4028 | Source identified |
| Graph-informed initialization is novel | Novelty | Needs comprehensive audit | N/A | **Do not claim** |
| Our simulator outperforms classical methods | Empirical | Future controlled experiments | N/A | **Not measured** |
