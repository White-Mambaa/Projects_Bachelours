# Research Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Proposed graph-informed transfer is already studied | High | High | Prior-work audit; frame as careful replication or narrow comparative study |
| Statevector costs grow exponentially | High | High | Start at small n; cap n and p; record memory and wall-clock |
| Optimizer variance obscures conclusions | Medium | High | Multiple seeds; fixed evaluation budgets; confidence intervals |
| Classical baselines are too weak | Medium | High | Include exact enumeration for small n and a competent local-search baseline |
| Incorrect gate/endianness conventions | Medium | High | Independent NumPy vs SDK cross-checks; analytical two-qubit identity |
| Results are misrepresented as quantum advantage | Medium | High | Label simulator outputs; distinguish theoretical and empirical claims |
| Cloud runtimes disconnect or change versions | Medium | Medium | Pin versions, save manifests, checkpoint results |
| Four-month deadline | High | High | Stage-gated milestones; prioritize p=1–3 and weighted Max-Cut |
