# Proposed Research Protocol (Pre-approval)

## Research objective
Develop a mathematically validated, reproducible software evaluation of QAOA on unweighted and positively weighted Max-Cut, studying depth, initialization, graph structure and optimization effort.

## Research questions
- RQ1: Is the weighted Max-Cut Hamiltonian implementation correct and independently verifiable?
- RQ2: How do circuit depth and graph family affect approximation ratio under fixed objective-evaluation budgets?
- RQ3: Does graph-informed parameter initialization improve performance over random/multistart initialization when all preprocessing and evaluations are accounted for?
- RQ4: How do simulator resource requirements scale with graph size and QAOA depth?

## Mathematical definitions
For graph G=(V,E,w), positive weights, C(z)=sum_(i,j) w_ij (z_i XOR z_j). H_C=1/2 sum_(i,j) w_ij (I-Z_i Z_j). H_B=sum_i X_i. |psi_p>=prod_(ell=p..1) exp(-i beta_ell H_B) exp(-i gamma_ell H_C)|+>^n. Expected cut F_p=<psi_p|H_C|psi_p>. Approximation ratio = F_p/C_max when C_max>0. Report best-sampled-cut ratio separately.

## Proposed experiments
1. Validate classical enumeration, Hamiltonian eigenvalues, normalization, and analytical single-edge p=1 identity.
2. Evaluate paths, cycles, complete graphs, sparse random graphs, and positively weighted variants with explicit random seeds.
3. Depths p=1,2,3 where computationally feasible. Hold optimizer evaluation budget constant across methods.
4. Compare exact optimum for small graphs, random-cut baseline (half total edge weight), greedy/local search, and QAOA variants.
5. Compare random initialization against simple graph-informed transfer, subject to prior-work review and supervisor approval.

## Minimum data recorded per run
Graph family, n, m, edge list/weights, graph seed, optimizer seed, p, parameter vector, optimizer, objective evaluation count, optimizer wall time, simulation wall time, expected cut, exact maximum (if available), approximation ratio, measurement shots (if used), best sampled cut (if used), software versions, hardware environment, and failures.

## Analysis
Report means and dispersion over independent seeds, objective evaluations and total compute cost, confidence intervals where appropriate, and failed/negative results. Do not equate statevector simulation wall-clock with physical quantum processor runtime. Keep graph training and evaluation sets separate for parameter transfer.

## Approval gates
No large-scale implementation before supervisor approval; do not expand into hardware or noisy device calibration unless scope is formally revised.
