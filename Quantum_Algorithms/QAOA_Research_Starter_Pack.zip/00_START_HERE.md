# QAOA Research Starter Pack — QT789_D

**Status:** Proposal preparation; awaiting faculty-guide approval. **Mode:** software-only, cloud computing. **Duration:** four months. **Focus:** weighted Max-Cut using the Quantum Approximate Optimization Algorithm (QAOA).

## Start here
1. Open `Decision_Lab.html` in a modern browser. No server or internet is required.
2. Present the *Why, Who, Existing Work, Contribution* narrative, then demonstrate the graph and p=1 QAOA calculation.
3. Select the project scope, inspect the proposed experimental protocol and approval checklist.
4. Review `Research_Protocol.md`, `Approval_Checklist.md`, `Risk_Register.md`, and `Source_and_Novelty_Ledger.md` with your guide.
5. **Do not report interactive demonstration outputs as completed experimental findings.** Implementation and systematic research begin after approval.

## Why these files exist
The HTML is an interactive **proposal decision aid**, not the research codebase. The Markdown documents specify what will be measured, which claims need evidence, and how scope is controlled. `experiment_manifest.example.json` illustrates a machine-readable experiment record.

## What we are not claiming
QAOA is an existing algorithm. Qiskit and OpenQAOA already implement related workflows. This course project will not claim quantum speedup, new algorithms, industrial deployment, or novel graph-parameter transfer without a prior-work audit and appropriate evidence.

## Source hierarchy
Foundational proofs must be mapped to the prescribed eight-textbook Octad; specific chapter/page references are pending edition verification. Original QAOA and other papers are used for historical attribution and novelty checking.
