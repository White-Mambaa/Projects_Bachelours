# Faculty Guide Approval Checklist

- [ ] Course code QT789_D and level 7 verified
- [ ] Four-month duration and software-only scope accepted
- [ ] Project title and main weighted Max-Cut benchmark approved
- [ ] Objectives and research questions approved
- [ ] Required mathematical rigor and expected deliverable format confirmed
- [ ] Prior work and novelty expectations clarified
- [ ] Graph families, circuit depths and simulator budget agreed
- [ ] Classical baselines and fair-comparison rules agreed
- [ ] Octad textbook reference requirement accepted
- [ ] Milestone and meeting cadence confirmed
- [ ] Any ethical, institutional, or repository requirements identified
- [ ] Written or email approval received

**Status:** Pending. This checklist is a preparation aid, not evidence of approval.
